/* 1 if debugging reference counting else 0 */
#undef DEBUG_REFCNT