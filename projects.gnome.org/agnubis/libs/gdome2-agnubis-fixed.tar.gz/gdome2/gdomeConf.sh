#
# Configuration file for using the gdome library
#
GDOME_LIBDIR="-L/opt/gdome1.2/lib"
GDOME_LIBS="-lgdome -L/usr/lib -lglib -lxml2"
GDOME_INCLUDEDIR="-I/opt/gdome1.2/include -I/opt/gdome1.2/include/libgdome -I/usr/include/glib-1.2 -I/usr/lib/glib/include -I/usr/include/libxml2/libxml -I/usr/include/libxml2"
MODULE_VERSION="gdome2-0.7.2"
