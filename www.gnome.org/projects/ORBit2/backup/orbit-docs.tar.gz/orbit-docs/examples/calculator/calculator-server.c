#include "calculator-impl.c"
#include <stdio.h>

int
main(int argc, char* argv[])
{
  CORBA_ORB                 orb;
  CORBA_Environment*        ev;
  PortableServer_ObjectId*  oid;
  Calculator                calculator;
  PortableServer_POA        root_poa;
  PortableServer_POAManager pm;
  CORBA_char*               objref;
  
  ev = g_new0(CORBA_Environment,1);

  CORBA_exception_init(ev);

  orb = CORBA_ORB_init(&argc, argv, "orbit-local-orb", ev);
  root_poa = (PortableServer_POA)CORBA_ORB_resolve_initial_references(orb, "RootPOA", ev);
  
  calculator = impl_Calculator__create(root_poa, ev);

  objref                 = CORBA_ORB_object_to_string(orb, calculator, ev);
  fprintf(stderr, "%s\n", objref);

  pm = PortableServer_POA__get_the_POAManager(root_poa, ev);
  PortableServer_POAManager_activate(pm, ev);
  CORBA_ORB_run(orb, ev);
  return 0;
}

