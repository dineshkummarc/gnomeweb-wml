
#include "orb/orbit.h"
#include "calculator.h"
#include <stdio.h>

int
main(int argc, char* argv[])
{
        CORBA_Environment ev;
        CORBA_ORB         orb;
        CORBA_Object      server;
        CORBA_double      res;
        gchar*            dummy_argv[2];
        gint              dummy_argc;

        dummy_argc = 1;
        dummy_argv[0] = argv[0];
        dummy_argv[1] = 0;

        CORBA_exception_init(&ev);
        orb = CORBA_ORB_init(&dummy_argc, dummy_argv, "orbit-local-orb", &ev);
        server = CORBA_ORB_string_to_object(orb, argv[1], &ev);
        res = Calculator_add(server,1.0, 2.0, &ev);
        fprintf(stdout,"Result: 1.0 + 2.0 = %2.0f\n", res);
        CORBA_Object_release(server,&ev);
        exit(0);
}
